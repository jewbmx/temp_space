
## the module: decryption.py
-place here: /Kodi/addons/plugin.video.scrubsv2/resources/lib/modules/


## the scraper: bstsrs_one.py
-place here: /Kodi/addons/plugin.video.scrubsv2/resources/lib/sources/working/


